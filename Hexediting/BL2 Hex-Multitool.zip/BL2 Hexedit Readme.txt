### Installation ###
Extract both files into the "steamapps\common\Borderlands 2\Binaries\Win32" folder.




### Informations ###

Scrolling through the inventory can bug out, like it can for vendors, for example.

So far these methods have been reported to fix it:

- Reopen the Inventory
- Use the Arrowkeys
- Switch around items